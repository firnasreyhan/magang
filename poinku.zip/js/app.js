$(function () {
    $('[data-tooltip="tooltip"]').tooltip()
})